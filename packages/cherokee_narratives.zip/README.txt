Cherokee Narratives (Supplementary Materials)
==============================================
Author: Durbin Feeling, et al.
Source: Cherokee Narratives Corpus

This package contains 17 traditional, historical, and contemporary Cherokee stories, dialogues, and accounts transcribed and edited by Dr. Durbin Feeling and contributors.

Features:
- Full Syllabary, Transliteration, and English translations.
- Word-by-word literal translations.
- Full Interlinear Glossed Text (IGT) morpheme breakdowns.
- Structured into 17 stories for the Cherokee Corpus Reader.
