Cherokee Narratives (Supplementary Materials)
==============================================
Author: Durbin Feeling, et al.
Source: Cherokee Narratives Corpus

Stories from Cherokee Narratives (edited by Durbin Feeling).

Features:
- Full Syllabary, Transliteration, and English translations.
- Word-by-word literal translations.
- Full Interlinear Glossed Text (IGT) morpheme breakdowns.
- Structured into 17 stories for the Cherokee Corpus Reader.
