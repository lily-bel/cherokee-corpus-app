Cherokee New Testament (Bible Package)
======================================
Source: Cherokee New Testament (1860 / American Bible Society)
Format: 27 Books, 260 Chapters, 7957 Verses

Contains the full Cherokee New Testament corpus with:
- Syllabary text
- Phonetic Roman transliteration
- English translation
- Structured for Reader by Book, Chapter, and Verse
